# Super Mario Bros World 1-1 Tutorial in Unity
Recreation of the World 1 Stage 1 in Unity using C#
	
### YouTube Tutorial Done Right

Thank you for showing your interest. Hopefully these tutorials will help us both in Unity :)

# Tutorial Overview (Tutorial 9 and On)
			
Bear with me the early tutorials are inconsistent and vary in quality so lets skip to the good stuff
##### All Tutorials So Far
	https://www.youtube.com/watch?v=vgq0n_68uMc&list=PLDj1WczptC7gdLlrP7j8cfVy-kTn2sHDJ


### Tutorial 13 
#### Fixed Wonky Jumping, Walk to Speed, and More 2D Assets to Come

![image](https://cloud.githubusercontent.com/assets/20171200/21540379/8d5aaea8-cd74-11e6-9039-9f97624c0c9d.png)


![image](https://cloud.githubusercontent.com/assets/20171200/21540172/1aac6f64-cd73-11e6-8879-5b2c8d4ca71b.png)










